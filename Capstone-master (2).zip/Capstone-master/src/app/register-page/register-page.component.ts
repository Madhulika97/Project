import { Component, OnInit } from '@angular/core';
import { bank_customer } from './register-page';
import { BankService } from './register-page.service';


@Component({
    selector: 'app-register-page',
    templateUrl: './register-page.component.html',
    styleUrls: ['./register-page.component.css']
})
export class REGISTERPAGEComponent implements OnInit {
    customer = new Customer();
    constructor( private _BookService : BankService) { }

    ngOnInit() {
    }
    addCustomer(): void{
        this._BookService.addCustomer(this.customer)
        .subscribe((response) => {console.log(response)}, (error) =>{
            console.log(error);
        });
    }
}
