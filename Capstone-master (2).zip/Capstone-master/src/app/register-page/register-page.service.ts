import {Http, RequestOptions, Headers} from '@angular/http';
import { Injectable} from '@angular/core';
import { Observable } from 'rxjs';
import { bank_customer } from './register-page';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { map } from 'rxjs/operators';
import 'rxjs/Rx';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';

@Injectable()
export class BankService{
    constructor(private _httpService: Http){}
    addCustomer(customer: Customer){
        let body=JSON.stringify(customer);
        let headers= new Headers({'Content-Type':'application/json'});
        let options = new RequestOptions({headers: headers});
        return this._httpService.post("URL",body,options);
    }
}