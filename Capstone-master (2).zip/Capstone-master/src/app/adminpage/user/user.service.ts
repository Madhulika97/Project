import {Http, Response, RequestOptions, Headers} from '@angular/http';
import { Injectable} from '@angular/core';
import { Observable } from 'rxjs';
import { bank_customer } from './user';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { map } from 'rxjs/operators';
import 'rxjs/Rx';
import { HttpClient } from '@angular/common/http';


@Injectable()
export class BankService{
    constructor(private _httpService: Http){}
    getAllCustomer(): Observable<bank_customer[]>{
        return this._httpService.get("http://localhostURL")
        .pipe(map((response: Response) => Response.json())
        .catch(this.handleError));
    }
    private handleError(error: Response){
        return Observable.throw(error);
    }
    
}